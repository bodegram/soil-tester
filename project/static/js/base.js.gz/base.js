let navMenu = document.getElementById('nav-menu')
navMenu.classList.add('nav-hide')

const openMenu = () =>{
    navMenu.classList.toggle('nav-hide')
}